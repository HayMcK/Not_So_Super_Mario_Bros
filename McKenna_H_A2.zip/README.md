# Not_So_Super_Mario_Bros    
Hayden McKenna  
ID: 2395864  
Section Number: CPSC350-03    
  

Run requirements: pass 2 arguments, the input file and what you wnat to be the output file, both .txt files  
EX: g++ *.cpp -o mario  
./mario input.txt output.txt  
  
Sources:  
  https://www.simplilearn.com/tutorials/cpp-tutorial/int-to-string-cpp#:~:text=In%20C%2B%2B%2C%20you%20can,std%3A%3Ato_string(num)%3B  
  https://www.youtube.com/watch?v=_Dx_DpTIUXQ  
  